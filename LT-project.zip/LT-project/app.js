const { connectDB } = require("./data/db");
const { run } = require("./controller/dssController");
const { testRead } = require("./service/testRead");

const readline = require("readline");

async function start() {
    await connectDB();

    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    console.log("=== Система підтримки прийняття рішень ===");
    console.log("1. Показати дані");
    console.log("2. Обчислити рейтинг\n");

    rl.question("Оберіть дію (1 або 2): ", async (answer) => {

        if (answer === "1") {
            await testRead();
        } else if (answer === "2") {
            await run();
        } else {
            console.log("Невірний вибір");
        }

        rl.close();
    });
}

start();