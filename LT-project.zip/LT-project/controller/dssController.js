const { calculate } = require("../service/dssService");

async function run() {
    const results = await calculate();

    console.log("Рейтинг альтернатив:");

    results.forEach((r, i) => {
        console.log(`${i + 1}. ${r.name} → ${r.score.toFixed(3)}`);
    });

    console.log("\nНайкращий вибір:", results[0].name);
}

module.exports = { run };