const { MongoClient } = require("mongodb");

const url = "mongodb://localhost:27017";
const dbName = "dss_bd";

let db;

async function connectDB() {
    const client = new MongoClient(url);

    await client.connect();
    console.log("Connected to MongoDB");

    db = client.db(dbName);
}

function getDB() {
    return db;
}

module.exports = { connectDB, getDB };