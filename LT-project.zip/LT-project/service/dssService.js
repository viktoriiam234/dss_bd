const { getDB } = require("../data/db");

function normalize(values, isMax) {
    const min = Math.min(...values);
    const max = Math.max(...values);

    
    if (max === min) {
        return values.map(() => 1);
    }

    return values.map(v => {
        if (isMax) {
            return (v - min) / (max - min);
        } else {
            return (max - v) / (max - min);
        }
    });
}

async function calculate() {
    const db = getDB();

    const alternatives = await db.collection("alternatives").find().toArray();
    const criteria = await db.collection("criteria").find().toArray();

    if (!alternatives.length || !criteria.length) {
        throw new Error("Немає даних у базі");
    }


    let matrix = alternatives.map(a => {
        if (!Array.isArray(a.values)) {
            throw new Error(`Альтернатива "${a.name}" не має масиву values`);
        }
        return a.values;
    });

    const criteriaCount = criteria.length;


    matrix.forEach((row, index) => {
        if (row.length !== criteriaCount) {
            throw new Error(
                `Альтернатива "${alternatives[index].name}" має ${row.length} значень, а критеріїв ${criteriaCount}`
            );
        }
    });

    let scores = [];

    for (let i = 0; i < alternatives.length; i++) {
        let score = 0;

        for (let j = 0; j < criteria.length; j++) {
            let column = matrix.map(row => row[j]);

            let normalized = normalize(column, criteria[j].isMax);

            score += normalized[i] * criteria[j].weight;
        }

        scores.push({
            name: alternatives[i].name,
            score: score
        });
    }

    scores.sort((a, b) => b.score - a.score);

    return scores;
}

module.exports = { calculate };