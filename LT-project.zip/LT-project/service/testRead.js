const { getDB } = require("../data/db");

async function testRead() {
    const db = getDB();

    const alternatives = await db.collection("alternatives").find().toArray();
    const criteria = await db.collection("criteria").find().toArray();

    console.log("Матриця оцінок:");

    console.table(alternatives.map(a => {
        let obj = { name: a.name };

        criteria.forEach((c, i) => {
            obj[c.name] = a.values[i];
        });

        return obj;
    }));
}

module.exports = { testRead };